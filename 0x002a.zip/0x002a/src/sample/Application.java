package sample;

public class Application {
    public User currUser;
    public Node startNode;

    public void getCharacterStats(){

    }
    public void movetoNext(){

    }
    public void updateCharacter(){

    }
    public void getAquestion(){

    }
    
}