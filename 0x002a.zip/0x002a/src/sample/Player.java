package sample;

public class Player extends User {

    public void giveAnswer(){

    }
    public void getEffect(){

    }
    public void finish(){

    }
}