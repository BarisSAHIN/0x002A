package sample;

public class Character {

}