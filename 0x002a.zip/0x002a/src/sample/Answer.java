package sample;

public class Answer extends Node {
    public Question nextLeft;
    public Question nextRight;

    public void GetSideEffects(){

    }
    public void GetNextQuestion(){

    }
    public void GetAvailableQuestions(){

    }
    public void AddSideEffect(){

    }

}