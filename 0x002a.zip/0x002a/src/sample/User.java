package sample;

public abstract class User {
    public Character Personality;

    public void makeSelection(){

    }

}