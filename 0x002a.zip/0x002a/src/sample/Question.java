package sample;


import javafx.util.Pair;
import java.util.LinkedList;

public class Question extends Node {
    public Answer answerLeft;
    public Answer answerRight;

    public void GetAnswers(){

    }
    public void GetPre(){


    }
    public void AddPrerequest(){


    }

}