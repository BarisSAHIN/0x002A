package sample;

public abstract class Node {

    public void getNodeSpecial(){

    }
    public void getNextNode(){

    }

}