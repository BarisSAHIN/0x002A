package sample;

public class Maker extends User {

    public void addQuestion(){

    }
    public void addAnswer(){

    }
    public void save(){

    }


}